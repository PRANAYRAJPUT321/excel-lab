#!/usr/bin/env bash
# Excel Lab -> GitHub.  The repo and the commit are already prepared.
# This just sends it. Double-click me, or run:  bash PUSH.command
cd "$(dirname "$0")"
echo ""
echo "Pushing Excel Lab to github.com/PRANAYRAJPUT321/excel-lab ..."
echo ""
echo "If it asks for a password, that is NOT your GitHub password."
echo "Make a token at  https://github.com/settings/tokens?type=beta"
echo "(Generate new token -> Repository access: excel-lab -> Permissions:"
echo " Contents = Read and write -> Generate) and paste that as the password."
echo ""
git push -u origin main && {
  echo ""
  echo "============================================"
  echo "  Pushed. Now tell Claude 'pushed' and it"
  echo "  will deploy it to Vercel."
  echo "============================================"
} || {
  echo ""
  echo "Push failed. Easiest alternative, no terminal needed:"
  echo "  1. Open https://github.com/PRANAYRAJPUT321/excel-lab"
  echo "  2. Click 'uploading an existing file'"
  echo "  3. Drag in all the files sitting next to this script"
  echo "  4. Click 'Commit changes'"
}
echo ""
read -r -p "Press Enter to close."
